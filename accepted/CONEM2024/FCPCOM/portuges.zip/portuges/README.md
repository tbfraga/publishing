Portuguese 1.2t
--------------

This is the babel style for Portuguese.

**This package is NOT being actively maintained, but bugs might
got fixed if you report them. If you want to take over maintenance
of this language style, please contact me at
http://www.texnia.com/contact.html .**

Changes 1.2r
------------

Months are now lowercased in all 'dialects'.

Changes 1.2t
------------

Don't use the deprecated \rm in ordinals.

